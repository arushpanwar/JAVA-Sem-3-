package com.company;
public interface ClassMaterial
{
    public void view();
}
