package com.company;

public interface user
{
    public void viewassessments();
    public void viewLecture();
    public void addComment();
    public void viewComment();
}
